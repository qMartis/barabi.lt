<?php

foreach ( glob( TEENGLOW_MEMBERSHIP_INC_PATH . '/general/dashboard/admin/*.php' ) as $module ) {
	include_once $module;
}

require_once TEENGLOW_MEMBERSHIP_INC_PATH . '/general/class-teenglowmembership-page-templates.php';
include_once TEENGLOW_MEMBERSHIP_INC_PATH . '/general/helper.php';
