<div class="qodef-m-social-login">
	<p class="qodef-m-social-login-title"><?php echo esc_html__( 'Or connect with social', 'teenglow-membership' ); ?></p>
	<div class="qodef-m-social-login-inner">
		<?php do_action( 'teenglow_membership_action_social_login_content' ); ?>
	</div>
</div>
