<?php

if ( is_user_logged_in() ) {
	teenglow_membership_template_part( 'widgets/login-opener', 'templates/logged-in-content' );
} else {
	teenglow_membership_template_part( 'widgets/login-opener', 'templates/logged-out-content' );
}
