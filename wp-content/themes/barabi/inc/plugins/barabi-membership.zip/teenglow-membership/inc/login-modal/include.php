<?php

include_once TEENGLOW_MEMBERSHIP_LOGIN_MODAL_PATH . '/helper.php';

foreach ( glob( TEENGLOW_MEMBERSHIP_LOGIN_MODAL_PATH . '/*/include.php' ) as $module ) {
	include_once $module;
}
