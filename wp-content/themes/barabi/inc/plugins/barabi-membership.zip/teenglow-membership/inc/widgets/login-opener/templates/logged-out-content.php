<a href="#" class="qodef-login-opener">
	<span class="qodef-login-opener-icon"><?php echo teenglow_core_get_svg_icon( 'login' ); ?></span>
</a>
