<div class="qodef-m-social-login qodef--facebook">
	<button type="submit" class="qodef-m-social-login-btn" data-social="facebook"><?php echo teenglow_membership_get_svg_icon( 'facebook-alt' ); ?></button>
</div>
