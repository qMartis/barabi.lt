<?php

include_once TEENGLOW_CORE_INC_PATH . '/search/widgets/search-opener/class-teenglowcore-search-opener.php';
