<?php

include_once TEENGLOW_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/helper.php';
include_once TEENGLOW_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/class-teenglowcore-standard-with-breadcrumbs-title.php';
