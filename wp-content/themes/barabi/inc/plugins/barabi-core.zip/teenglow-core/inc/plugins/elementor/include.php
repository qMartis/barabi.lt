<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once TEENGLOW_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once TEENGLOW_CORE_PLUGINS_PATH . '/elementor/class-teenglowcore-elementor-section-handler.php';
	include_once TEENGLOW_CORE_PLUGINS_PATH . '/elementor/class-teenglowcore-elementor-container-handler.php';
}
