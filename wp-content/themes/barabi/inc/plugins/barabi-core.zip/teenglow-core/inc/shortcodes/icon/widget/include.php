<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/icon/widget/class-teenglowcore-icon-widget.php';
