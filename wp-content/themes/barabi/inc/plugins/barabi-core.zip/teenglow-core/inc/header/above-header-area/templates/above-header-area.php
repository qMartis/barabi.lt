<?php if ( $show_header_area ) { ?>
    <div id="qodef-above-header-area">
        <div class="qodef-above-header-widget-holder">
            <?php teenglow_core_get_header_widget_area( 'above' ); ?>
        </div>
    </div>
<?php } ?>
