<?php

include_once TEENGLOW_CORE_PLUGINS_PATH . '/contact-form-7/class-teenglowcore-contact-form-7.php';
