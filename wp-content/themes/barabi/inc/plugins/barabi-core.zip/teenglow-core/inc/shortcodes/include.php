<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/helper.php';
include_once TEENGLOW_CORE_SHORTCODES_PATH . '/class-teenglowcore-shortcodes.php';
