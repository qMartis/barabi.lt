<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/icon-list-item/class-teenglowcore-icon-list-item-shortcode.php';
