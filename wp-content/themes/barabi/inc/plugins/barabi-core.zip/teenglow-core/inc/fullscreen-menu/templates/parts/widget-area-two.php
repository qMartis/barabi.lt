<?php if( is_active_sidebar( 'qodef-full-screen-menu-widget-area-two' ) ) : ?>
    <div class="qodef-fullscreen-widget-area-two">
        <div class="qodef-widget-holder qodef--two">
            <?php dynamic_sidebar('qodef-full-screen-menu-widget-area-two'); ?>
        </div>
    </div>
<?php endif; ?>
