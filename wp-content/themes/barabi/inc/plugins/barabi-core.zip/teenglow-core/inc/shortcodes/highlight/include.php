<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/highlight/class-teenglowcore-highlight-shortcode.php';
