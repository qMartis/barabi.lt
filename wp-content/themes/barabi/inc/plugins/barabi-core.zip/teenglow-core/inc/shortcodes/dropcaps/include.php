<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/dropcaps/class-teenglowcore-dropcaps-shortcode.php';
