<?php

include_once TEENGLOW_CORE_CPT_PATH . '/class-teenglowcore-custom-post-types.php';
