<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php teenglow_core_template_part( 'shortcodes/video-button', 'templates/parts/image', '', $params ); ?>
	<?php teenglow_core_template_part( 'shortcodes/video-button', 'templates/parts/button', '', $params ); ?>
</div>
