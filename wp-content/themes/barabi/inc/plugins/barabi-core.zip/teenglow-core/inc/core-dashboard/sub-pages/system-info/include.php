<?php

include_once TEENGLOW_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-teenglowcore-dashboard-system-info-page.php';
