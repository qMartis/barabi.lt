<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/video-button/class-teenglowcore-video-button-shortcode.php';
