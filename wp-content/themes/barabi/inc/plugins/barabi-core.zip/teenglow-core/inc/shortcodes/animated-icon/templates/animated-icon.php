<div <?php qode_framework_class_attribute( $holder_classes ); ?> <?php qode_framework_inline_style( $holder_styles ); ?>>
	<div class="qodef-e-inner">
		<?php teenglow_core_template_part( 'shortcodes/animated-icon', 'templates/parts/' . $icon_type, '', $params ); ?>
	</div>
</div>