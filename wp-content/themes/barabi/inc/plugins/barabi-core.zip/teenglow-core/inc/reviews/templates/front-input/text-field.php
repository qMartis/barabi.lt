<p class="comment-form-comment">
	<textarea id="comment" name="comment" placeholder="<?php esc_attr_e( 'Your Comment *', 'teenglow-core' ); ?>" cols="45" rows="8" maxlength="65525" required="required"></textarea>
</p>

