<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/textual-list/class-teenglowcore-textual-list-shortcode.php';