<?php

include_once TEENGLOW_CORE_INC_PATH . '/search/layouts/covers-header/helper.php';
include_once TEENGLOW_CORE_INC_PATH . '/search/layouts/covers-header/class-teenglowcore-covers-header-search.php';
