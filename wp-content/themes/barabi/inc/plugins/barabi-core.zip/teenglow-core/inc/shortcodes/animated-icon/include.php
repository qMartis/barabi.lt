<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/animated-icon/class-teenglowcore-animated-icon-shortcode.php';
