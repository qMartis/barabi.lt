<?php

include_once TEENGLOW_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-teenglowcore-blog-list-widget.php';
include_once TEENGLOW_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-teenglowcore-simple-blog-list-widget.php';
