<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/icon-list-item/widget/class-teenglowcore-icon-list-item-widget.php';
