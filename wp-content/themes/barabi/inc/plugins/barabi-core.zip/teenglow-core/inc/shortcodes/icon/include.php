<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/icon/class-teenglowcore-icon-shortcode.php';
