<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/split-showcase/class-teenglowcore-split-showcase-shortcode.php';
