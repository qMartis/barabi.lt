<?php

include_once TEENGLOW_CORE_INC_PATH . '/spinner/layouts/two-rotating-circles/helper.php';
