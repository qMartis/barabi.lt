<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/simple-slider/class-teenglowcore-simple-slider-shortcode.php';
