<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/progress-bar/class-teenglowcore-progress-bar-shortcode.php';
