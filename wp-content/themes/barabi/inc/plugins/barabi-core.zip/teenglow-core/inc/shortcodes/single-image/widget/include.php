<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/single-image/widget/class-teenglowcore-single-image-widget.php';
