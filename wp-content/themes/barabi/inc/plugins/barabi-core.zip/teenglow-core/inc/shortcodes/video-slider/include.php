<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/video-slider/class-teenglowcore-video-slider-shortcode.php';
