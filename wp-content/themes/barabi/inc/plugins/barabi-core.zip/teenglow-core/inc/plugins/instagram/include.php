<?php

include_once TEENGLOW_CORE_PLUGINS_PATH . '/instagram/helper.php';
