<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/custom-font/widget/class-teenglowcore-custom-font-widget.php';
