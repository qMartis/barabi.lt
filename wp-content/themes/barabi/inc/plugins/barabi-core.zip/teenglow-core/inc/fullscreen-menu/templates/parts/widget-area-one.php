<?php if( is_active_sidebar( 'qodef-full-screen-menu-widget-area-one' ) ) : ?>
    <div class="qodef-fullscreen-widget-area-one">
        <div class="qodef-widget-holder qodef--one">
            <?php dynamic_sidebar('qodef-full-screen-menu-widget-area-one'); ?>
        </div>
    </div>
<?php endif; ?>
