<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/image-gallery/class-teenglowcore-image-gallery-shortcode.php';
