<?php

get_header();

// Include cpt content template
teenglow_core_template_part( 'post-types/tutorial', 'templates/content' );

get_footer();
