<?php

include_once TEENGLOW_CORE_SHORTCODES_PATH . '/google-map/class-teenglowcore-google-map-shortcode.php';
